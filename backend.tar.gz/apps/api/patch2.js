const fs = require('fs');
const path = 'node_modules/@prisma/adapter-mariadb/dist/index.js';
let code = fs.readFileSync(path, 'utf8');
code = code.replace(
  'return (value instanceof Date ? value : new Date(typeof value === "string" ? value.replace(/ /g, "T") + "Z" : `${value}Z`)).toISOString().replace(/(\\.000)?Z$/, "+00:00");',
  'try { return (value instanceof Date ? value : new Date(typeof value === "string" ? value.replace(/ /g, "T") + "Z" : `${value}Z`)).toISOString().replace(/(\\.000)?Z$/, "+00:00"); } catch(e) { console.log("INVALID DATE VALUE:", typeof value, value); throw e; }'
);
fs.writeFileSync(path, code);
console.log('Patched with logging.');
