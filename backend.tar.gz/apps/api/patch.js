const fs = require('fs');
const path = 'node_modules/@prisma/adapter-mariadb/dist/index.js';
let code = fs.readFileSync(path, 'utf8');
code = code.replace(
  'return (/* @__PURE__ */ new Date(`${value}Z`)).toISOString().replace(/(\\.000)?Z$/, "+00:00");',
  'return (value instanceof Date ? value : new Date(typeof value === "string" ? value.replace(/ /g, "T") + "Z" : `${value}Z`)).toISOString().replace(/(\\.000)?Z$/, "+00:00");'
);
fs.writeFileSync(path, code);
console.log('Patched adapter-mariadb successfully.');
