// Hostinger Node.js Passenger Entry Point
require('./apps/api/dist/main.js');
