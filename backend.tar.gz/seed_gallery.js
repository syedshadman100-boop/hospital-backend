const mysql = require('mysql2/promise');
const crypto = require('crypto');

const galleryImages = [
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/pic.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/08/WhatsApp-Image-2024-07-27-at-13.27.41_f032e903.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal1b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal2b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal3b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal4b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal5b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal6b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal7b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal8b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal10b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal11b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal12b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal13b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal14b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal16b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal17b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal18b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal19b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal20b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal23b.jpg",
  "https://www.agraheartcentre.com/wp-content/uploads/2024/07/gal9b.jpg"
];

const categories = [
  "Infrastructure",
  "Operation Theatre",
  "Cath Lab",
  "ICU",
  "Doctors",
  "Patients",
  "Events",
  "Awards",
  "Media Coverage"
];

async function main() {
  const connection = await mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '',
    database: 'hospital'
  });

  console.log('Clearing existing gallery...');
  await connection.execute('DELETE FROM Gallery');

  console.log('Seeding new gallery images with random categories...');
  for (let i = 0; i < galleryImages.length; i++) {
    const id = crypto.randomUUID();
    const category = categories[i % categories.length];
    await connection.execute(
      'INSERT INTO Gallery (id, title, fileUrl, fileType, category, sortOrder, isActive, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [id, `Agra Heart Centre - ${category} ${i + 1}`, galleryImages[i], 'image', category, i, true, new Date()]
    );
  }

  console.log('Successfully seeded gallery!');
  await connection.end();
}

main().catch(console.error);
